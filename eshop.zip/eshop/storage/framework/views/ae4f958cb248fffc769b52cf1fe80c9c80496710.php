<?php $__env->startSection('content'); ?>
<?php $total = 0 ?>
        <?php if(session('cart')): ?>
            <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $total += $details['price'] * $details['quantity'] ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
<form action="/createorder" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" value="2023-05-18" name="order_date"><br>
                            Total Amount :
                            <input type="text" value="<?php echo e($total); ?>" name="total_amount"><br>
                            Customer Name :
                            <input type="text" value="" name="cus_name"><br>
                            Customer Mobile :
                            <input type="text" value="" name="cus_mobile"><br>
                            Customer Email :
                            <input type="text" value="" name="cus_email"><br>
                            Delivery Address :
                            <input type="text" value="" name="delivery_address"><br>

                            <button class="px-4 py-2 text-white bg-blue-800 rounded"><i class="fa fa-trash-o"></i>Place Order</button>
                        </form>
                        <a href="/products" class="btn btn-warning"><i class="fa fa-angle-left"></i> Continue Shopping</a>
                
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\interview-assignment\eshop\resources\views/order.blade.php ENDPATH**/ ?>