<?php $__env->startSection('content'); ?>

<script src="https://js.stripe.com/v3/"></script>


<?php $total = 0 ?>
<?php if(session('cart')): ?>
    <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $total += $details['price'] * $details['quantity'] ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>
<div id="card-errors"></div>
<form id="payment-form" action="/pay" method="post">
                            <div id="card-element"></div>
                            <?php echo csrf_field(); ?>
                            
                            <input type="hidden" value="2023-05-18" name="order_date"><br>
                            Total Amount $:
                            <input type="text" value="<?php echo e($total); ?>" name="total_amount"><br>
                            Card Holder Name :
                            <input type="text" value="" name="card_name"><br>
                            Card Number :
                            <input type="text" value="" name="card_number"><br>
                            Expiry Date :
                            <input type="text" value="" name="exp_date"><br>
                            CVC :
                            <input type="text" value="" name="cvc_no"><br>
                            <input type="hidden" name="stripeToken" id="stripeToken">
                            <button type="submit" class="px-4 py-2 text-white bg-blue-800 rounded"><i class="fa fa-trash-o"></i>Pay Now</button>
                        </form>
                        <script>
                            window.onload = function() {
                            var stripe = Stripe('pk_test_51N9kDkK5mrnBdgFu4SUNS26LPYCaJbG4gk4Y92QwFR2IutNigvkc9EEE2ULWymss0hHnTb8fI5iNT6Ek1fabcuG800IXxycp9a');
                            var elements = stripe.elements();
                            var cardElement = elements.create('card');
                            cardElement.mount('#card-element');

                            var form = document.getElementById('payment-form');
                            console.log('Before adding event listener');
                            form.addEventListener('submit', function(event) {
                                event.preventDefault();

                                stripe.createToken(cardElement).then(function(result) {
                                    if (result.error) {
                                        var errorElement = document.getElementById('card-errors');
                                        errorElement.textContent = result.error.message;
                                        console.log('my error'+errorElement.textContent);
                                    } else {
                                        var tokenInput = document.getElementById('stripeToken');
                                        tokenInput.value = result.token.id;
                                        console.log(result.token.id);
                                        form.submit();
                                    }
                                });
                            });
                            console.log('After adding event listener');
                        };
                        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\interview-assignment\eshop\resources\views/payment.blade.php ENDPATH**/ ?>