<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\OrdersController;
use App\Http\Controllers\PaymentController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('products');
});

Route::get('/products', function () {
    return view('products');
});

//Route::get('/products',[ProductController::class, 'viewProducts']);

Route::post('/orders/{id}/item',[CartController::class,'addToCart']);

Route::get('/orders',[CartController::class, 'cartList']);

Route::post('/removeitem',[CartController::class,'remove']);

Route::get('/order', function () {
    return view('order');
});

Route::post('/createorder',[OrdersController::class,'createOrder']);

Route::get('/payment', function () {
    return view('payment');
});

Route::post('/pay',[PaymentController::class,'processPayment']);