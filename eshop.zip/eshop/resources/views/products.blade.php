@extends('layouts.frontend')

@section('content')
    <div class="container px-6 mx-auto">
        <h3 class="text-2xl font-medium text-gray-700">Product List</h3>
      
        <div class="grid grid-cols-1 gap-6 mt-6 sm:grid-cols-2">
        <table class="table table-bordered table-hover">
            <thead>
                <th>Product</th>
                <th width="600px" align="center">Name&nbsp;&nbsp;<a href="/products?sort=product_name&direction=asc">^</a>&nbsp;<a href="/products?sort=product_name&direction=desc">v</a></th>                
                <th align="center">Brand</th>
                <th align="center">Price&nbsp;&nbsp;<a href="?sort=product_price&direction=asc">^</a>&nbsp;<a href="?sort=product_price&direction=desc">v</a></th>
                <th width="300px">...</th>
            </thead>
            <tbody id="product-list">
                
            </tbody>
        </table>
        <table>
            <tr>
                <td id="paginationHtml"></td>
            </tr>
        </table>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        var currentPageNo = 0;
        var sortBy = 'product_price';
        var sortDirection = 'asc';
        //var currentSortBy = null; // Track the current sort parameter
        $(document).ready(function() {
            loadProducts(1);
        });

        function loadProducts(pageNo) {
            var urlLink = '/api/products?page='+pageNo+'&sort=' + sortBy;
            
            if(pageNo == 1){
                urlLink = '/api/products?page='+pageNo+'&sort=' + sortBy;
            }else{
                urlLink = '/api/products?page='+pageNo+'&sort=' + sortBy;
            }

            $.ajax({
                url: urlLink,
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    displayProducts(response);
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        }

        /*function sortProducts(sortBy) {
            loadProducts(currentPageNo, sortBy);
        }*/

        function sortProducts(sortBy,CurrPage,sortDirection) {
            var urlLink = '/api/products?sort=' + sortBy + '&page='+CurrPage;
            console.log(urlLink);
            $.ajax({
                url: urlLink,
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    displayProducts(response);
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        }
        /*function displayProducts(products,sortBy) {
            var productHtml = '';
            var paginationHtml = '';
            var nextPageNo = 0;
            var prevPageNo = 0;  
            
            var x =0; 
            var urlSortBy = sortBy ? '&sort=' + sortBy : '';
                        
            $.each(products.data, function(index, product) {
                productHtml += '<tr>';
                productHtml += '<td><img src="'+product.product_pic+'" alt=""></td>';
                productHtml += '<td width="600px" align="center">'+product.product_name+'</td>';
                productHtml += '<td align="center">'+product.product_brand+'</td>';
                productHtml += '<td align="center">'+product.product_price+'</td>';
                productHtml += '<td width="300px">';
                productHtml += '<form action="/orders/'+product.product_id+'/item" method="POST">';
                productHtml += '@csrf';
                productHtml += '<input type="hidden" value="'+product.product_id+'" name="product_id">';
                productHtml += '<button class="px-4 py-2 text-white bg-blue-800 rounded">Add To Cart</button>';
                productHtml += '</form>';
                productHtml += '</td>';
                productHtml += '</tr>';                
                
                //productHtml += '</div>';
                //productHtml += '</div>';
                
                // Add more HTML markup to display other product details
            });           

            
            nextPageNo = products.current_page + 1;
            prevPageNo = products.current_page - 1;
            currentPageNo = products.current_page;

            productHtml += '<tr>';
            productHtml += '<td colspan="4">';

            if(products.current_page != 1){
                productHtml += '<a href="#" onclick="loadProducts(1,'+urlSortBy+');" >First Page</a>&nbsp;&nbsp;';
                productHtml += '<a href="#" onclick="loadProducts('+(products.current_page - 1)+','+urlSortBy+');" >Previous Page</a>&nbsp;&nbsp;';
            }

            for(i=products.current_page+1; i < products.last_page; i++){
                if(x < 10){
                    productHtml += '<a href="#" onclick="loadProducts('+ i +', '+urlSortBy+');" >'+i+'</a>&nbsp;&nbsp;';
                }
                x++;
            }

            if(products.current_page != products.last_page){
                productHtml += '<a href="#" onclick="loadProducts('+ products.last_page +' ',+urlSortBy+');" >Last Page</a>&nbsp;&nbsp;';
            }
            
            productHtml += '</tr>';
            productHtml += '</td>';
            $('#product-list').html(productHtml);
            //$('#paginationHtml').html(paginationHtml);
        }*/

        function displayProducts(products) {
            var productHtml = '';
            var paginationHtml = '';
            var nextPageNo = 0;
            var prevPageNo = 0;  
            
            var x =0; 
                        
            $.each(products.data, function(index, product) {
                productHtml += '<tr>';
                productHtml += '<td><img src="'+product.product_pic+'" alt=""></td>';
                productHtml += '<td width="600px" align="center">'+product.product_name+'</td>';
                productHtml += '<td align="center">'+product.product_brand+'</td>';
                productHtml += '<td align="center">'+product.product_price+'</td>';
                productHtml += '<td width="300px">';
                productHtml += '<form action="/orders/'+product.product_id+'/item" method="POST">';
                productHtml += '@csrf';
                productHtml += '<input type="hidden" value="'+product.product_id+'" name="product_id">';
                productHtml += '<button class="px-4 py-2 text-white bg-blue-800 rounded">Add To Cart</button>';
                productHtml += '</form>';
                productHtml += '</td>';
                productHtml += '</tr>';                
                
                //productHtml += '</div>';
                //productHtml += '</div>';
                
                // Add more HTML markup to display other product details
            });           

            
            nextPageNo = products.current_page + 1;
            prevPageNo = products.current_page - 1;
            currentPageNo = products.current_page;

            productHtml += '<tr>';
            productHtml += '<td colspan="4">';

            if(products.current_page != 1){
                productHtml += '<a href="#" onclick="loadProducts(1);" >First Page</a>&nbsp;&nbsp;';
                productHtml += '<a href="#" onclick="loadProducts('+(products.current_page - 1)+');" >Previous Page</a>&nbsp;&nbsp;';
            }

            for(i=products.current_page+1; i < products.last_page; i++){
                if(x < 10){
                    productHtml += '<a href="#" onclick="loadProducts('+ i +');" >'+i+'</a>&nbsp;&nbsp;';
                }
                x++;
            }

            if(products.current_page != products.last_page){
                productHtml += '<a href="#" onclick="loadProducts('+ products.last_page +');" >Last Page</a>&nbsp;&nbsp;';
            }
            
            productHtml += '</tr>';
            productHtml += '</td>';
            $('#product-list').html(productHtml);
            //$('#paginationHtml').html(paginationHtml);
        }

        $(document).on('click', 'th a', function(e) {
            e.preventDefault();
            sortBy = $(this).attr('href').split('?sort=')[1];
            sortDirection = $(this).attr('href').split('?direction=')[2];
            console.log(sortBy);
            sortProducts(sortBy,currentPageNo,sortDirection);
        });
    </script>
@endsection