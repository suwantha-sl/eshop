<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SaampleKart</title>
</head>

<!-- css file -->
<link rel="stylesheet" href="site.css">

 <!-- font awesome icon -->
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<body>
    <nav>
        <div class="nav-responsive">
            <img src="/images/phone-icon3.png" alt="image" class="logo" id="logo">
            
            <div class="access">
                <a href="#" id="notification"><i class="fa fa-shopping-bag"></i>&nbsp;&nbsp;products</a>
                <a href="#" id="cart"><i class="fa fa-shopping-cart"></i>&nbsp;&nbsp;my cart</a>                
                <a href="#" id="account"><i class="fa fa-phone"></i></a>
            </div>
        </div>      
    </nav>

<!-- main section -->
<main id="main" >
    <!-- categories section -->
    <section id="categories">
        @yield('content')
    </section>
<!-- end of categories section -->


<!-- Footer section -->
    <footer>
        <p id="footer-title">our support team</h3p>
        <div class="footer">
            <div class="support">
                <ul>
                    <h3>Know About Us</h3>
                    <li><a href="#" id="about">Know Us</a></li>
                    <li><a href="#" id="Refund-policy">Refund Policy</a></li>
                    <li><a href="#" id="policy">Our Policy</a></li>
                    <li><a href="#" id="return-product">How to Return ?</a></li>
                    <li><a href="#" id="terms">Term & Conditios</a></li>
                    <li><a href="#" id="privacy">Privacy Policy</a></li>
                </ul>
            </div>

            <div class="social-media">

                <ul>
                    <h3>Contact Us</h3>
                    <li><i class="fa fa-facebook"></i><a href="#" id="facebook">Facebook</a></li>
                    <li><i class="fa fa-twitter"></i><a href="#" id="twitter">Twitter</a></li>
                    <li><i class="fa fa-instagram"></i><a href="#" id="facebook">Instagram</a></li>
                    <li><i class="fa fa-telegram"></i><a href="#" id="facebook">Telegram</a></li>
                </ul>
            </div>

            <div class="address">
                <h3>Office Address</h3>
                <p>Building Ashiana,Cubbon Park,</p>
                <p>Bengaluru,560103,</p>
                <p>Karnatka,India</p>
                <p>Phone No : 9876543210</p>
            </div>
        </div>

        <div id="copyright">
            <p>&#169 : 2020 SampleKart.com. All Rights Reserved</p>
        </div>
    </footer>
<!-- end of footer section -->

</main>
<!-- end of main -->


<!-- details page section -->
<div id="details-page">
    <div class="details">
        <div class="items-detail">
            <div class="image-container">
                <img src="/images/redmiK20.jpg" alt="" id="details-img">
            </div>
            <div class="details-card">
                <h2 id="detail-title">Samsung Galaxy</h2>
                <h4 id="detail-price">Price : Rs 9,999</h4>
                <p id="you-save">You save : (Rs 4,000)</p>
                <p id="delievery"><strong>Delivery : </strong> In 3 - 4 days</p>
                <p id="spec"><strong>Specification :</strong>

                    <ul>
                        <li>13MP AI triple main camera + 2MP bokeh (depth of field) camera + 2MP macro camera with photo, video, professional mode panorama, portrait, time-lapse etc. | 16MP front punch hole camera</li>

                        <li>Lorem ipsum, dolor sit amet consectetur adipisicing elit. </li>

                        <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nihil maxime reiciendis laborum! Velit odit molestias architecto doloremque est sapiente. </li>
                    </ul>
                </p>
                <button id="carts">Add to Cart</button>
                <button id="buy">Back</button>
            </div>
        </div>
    </div>
</div>
<!-- end of page detail -->


<!-- cart list section -->
<div id="cart-container">
    <p id="cart-title">Your <strong>Cart</strong></p id="cart-title">
    <div id="empty-cart">
        <h1>Your Cart is Empty...</h1>
    </div>

    <div id="cart-with-items">
        <div class="cart-column">
            <h3>Product</h3>
            <h3>Product Name</h3>
            <h3>Total </h3>
            <h3>Quantity</h3>
            <h3>Remove</h3>
        </div>
        <div id="item-body">
        </div>
        <div id="total">
            <h3 id="total-items"></h3>
            <h2 id="total-amount"></h2>
            <h3 id="you-saved"></h3>
        </div>
    </div>
</div>
<script src="/site.js"></script>
</body>
</html>