<?php

namespace App\Listeners;

use App\Events\OrderSavedEvent;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;


class OrderSavedListener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  OrderSavedEvent  $event
     * @return void
     */
    public function handle(OrderSavedEvent $event)
    {
        //
        $order = $event->order;
        return $order;
    }
}
