<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use App\Models\Product;

class CartApiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Add selected items to shopping cart
     */
    public function addToCart(Request $request){
        $addStatus = 0;
        try{
            $product = Product::findorFail($request->product_id);            
            //$cart = session()->get('cart', []);

            if(!session()->has('cart')){
                $cart = array();
                array_push($cart,[
                    "product" =>$product->product_id,
                    "name" => $product->product_name,
                    "quantity" => 1,
                    "price" => $product->product_price,
                    "image" => $product->product_pic
                ]);
                session()->put('cart', $cart);
            }else{
                $cart = session()->get('cart', []);
                $indexID = $this->exists($request->product_id,$cart);
                //dd($cart);
                if($indexID == -1){
                    array_push($cart,[
                        "product" =>$product->product_id,
                        "name" => $product->product_name,
                        "quantity" => 1,
                        "price" => $product->product_price,
                        "image" => $product->product_pic
                    ]);
                }else{
                    $cart[$indexID]['quantity']++;
                }
                session()->put('cart', $cart);
            }

            
            /*if(isset($cart[$request->product_id])) {            
                $cart[$request->product_id]['quantity']++;
                
            } else {
                $cart[$request->product_id] = [
                    "name" => $product->product_name,
                    "quantity" => 1,
                    "price" => $product->product_price,
                    "image" => $product->product_pic
                ];
                
            }*/
            
            
            $cart_test = session()->get('cart', []);
            //dd($cart_test);
            //Session::put('cart',$cart);
            $addStatus = 1;
        }catch(ModelNotFoundException $e){
            $addStatus = 0;
        }

        return view('products');
    }

    private function exists($id, $cart)
    {
        for ($i = 0; $i < count($cart); $i++) {
            if ($cart[$i]['product'] == $id) {
                return $i;
            }
        }
        return -1;
    }

    /**
     * Update cart items eg: quantity
     */
    public function updateCart(Request $request)
    {
        if($request->id && $request->quantity){
            $cart = session()->get('cart');
            $cart[$request->id]["quantity"] = $request->quantity;
            session()->put('cart', $cart);
            //session()->flash('success', 'Cart updated successfully');
        }
    }

    /**
     * Get cart items list
     */
    public function cartList(){
        //$cartItems = \Cart::getContent();
       // $cartItems = session()->get('cart');
        // dd($cartItems);
        return view('cart');
    }

    /**
     * Remove items from the cart
     */
    public function remove(Request $request)
    {
        if($request->id) {
            $cart = session()->get('cart');
            if(isset($cart[$request->id])) {
                unset($cart[$request->id]);
                session()->put('cart', $cart);
            }
            //session()->flash('success', 'Product removed successfully');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
