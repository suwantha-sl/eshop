<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Bus;
use App\Jobs\SaveOrderJob;

class OrdersController extends Controller
{
    //
    public function createOrder(Request $request){
        // calculate cart total
        $totalCart = 0;
        $cart = session()->get('cart', []);

        for ($i = 0; $i < count($cart); $i++) {
            $totalCart += $cart[$i]['quantity'] * $cart[$i]['price'];            
        }

        $order_date = date('Y-m-d');
        $totalAmount = $totalCart;

        $orderDetails = $request->validate([                           
            'cus_email' => 'required|max:255',
            'cus_name' => 'required|max:255',
            'cus_mobile' => 'required|max:10',
            'delivery_address' => 'required',
        ]);
        
        $orderCollection = collect($orderDetails);
        $orderFullInfo = $orderCollection->merge(['order_date'=>$order_date, 'total_amount'=>$totalAmount]);
        $orderFullInfo = array_merge($orderDetails, [
            'order_date' => $order_date,
            'total_amount' => $totalAmount,
        ]);
        
        // Dispatch the job to the queue        
        $retVal = SaveOrderJob::dispatch($orderFullInfo)->onQueue('orders');
        
        dd($retVal);

    }
}
