<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class ProductController extends Controller
{
    //

    public function getProducts(){
        //GetProductList::dispatch();
        $productList = Product::select("*")->where('active_flag','Y')->sortable()->paginate(10);
        return response()->json(['productList'=>$productList]);
    }

    public function viewProducts(){
        //$itemList = json_decode($this->getProducts(),true);
        return view('products');
    }

    public function addToCart($id)
    {
        $product = Product::findOrFail($id);
          
        $cart = session()->get('cart', []);
  
        if(isset($cart[$id])) {
            $cart[$id]['quantity']++;
        } else {
            $cart[$id] = [
                "name" => $product->name,
                "quantity" => 1,
                "price" => $product->price,
                "image" => $product->image
            ];
        }
          
        session()->put('cart', $cart);
        return redirect()->back()->with('success', 'Product added to cart successfully!');
    }
}
