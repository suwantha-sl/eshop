<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use App\Models\Product;

class CartController extends Controller
{
    //
    public function addToCart(Request $request,$id){
        $addStatus = false;
        try{
            $product = Product::findorFail($request->product_id);            
            //$cart = session()->get('cart', []);

            if(!session()->has('cart')){
                $cart = array();
                array_push($cart,[
                    "product" =>$product->product_id,
                    "name" => $product->product_name,
                    "quantity" => 1,
                    "price" => $product->product_price,
                    "image" => $product->product_pic
                ]);
                session()->put('cart', $cart);
            }else{
                $cart = session()->get('cart', []);
                $indexID = $this->exists($request->product_id,$cart);
                //dd($cart);
                if($indexID == -1){
                    array_push($cart,[
                        "product" =>$product->product_id,
                        "name" => $product->product_name,
                        "quantity" => 1,
                        "price" => $product->product_price,
                        "image" => $product->product_pic
                    ]);
                }else{
                    $cart[$indexID]['quantity']++;
                }
                session()->put('cart', $cart);
            }
                        
            
            $cart_test = session()->get('cart', []);
            //dd($cart_test);
            //Session::put('cart',$cart);
            $addStatus = true;
        }catch(ModelNotFoundException $e){
            $addStatus = false;
        }
        
        return view('products');
    }

    private function exists($id, $cart)
    {
        for ($i = 0; $i < count($cart); $i++) {
            if ($cart[$i]['product'] == $id) {
                return $i;
            }
        }
        return -1;
    }

    public function cartList(){
        //$cartItems = \Cart::getContent();
       // $cartItems = session()->get('cart');
        // dd($cartItems);
        return view('cart');
    }

    /**
     * remove item from the cart
     */
    public function remove(Request $request)
    {
        if($request->product_id) {
            $cart = session()->get('cart');
            $indexID = $this->exists($request->product_id, $cart);
            
            if($indexID == -1){

            }else{
                unset($cart[$indexID]);
                session()->put('cart', array_values($cart));
            }
            return view('cart');
            //session()->flash('success', 'Product removed successfully');
        }
    }
}
