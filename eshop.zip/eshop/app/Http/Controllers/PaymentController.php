<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Stripe\Charge;
use Stripe\Stripe;

class PaymentController extends Controller
{
    //
    public function processPayment(Request $request){
        $request->validate([
            'card_name' => 'required',
            'card_number' => 'required',
            'exp_date' => 'required',
            'cvc_no' => 'required',
            'total_amount' => 'required',
        ]);

        Stripe::setApiKey('sk_test_51N9kDkK5mrnBdgFuQPtUNhrBnNpSjlMDWxS8NEQocTHIsaE2N2hz0WGoc7dyOwtZ4muHhIWitogTKsYwXKUEpr7P00XlgPtJ0E');
        $totalAmtCents = ($request->total_amount)*100;
        // Create a charge
        try {
            $charge = Charge::create([
                'amount' => $totalAmtCents, // Amount in cents
                'currency' => 'usd',
                'description' => 'Example charge',
                'source' => $request->stripeToken,
            ]);

            // Payment successful, do something with the charge data
            // For example, save it to your database

            return redirect()->back()->with('success', 'Payment successful.');
        } catch (\Exception $e) {
            // Payment failed, handle the error
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
}
