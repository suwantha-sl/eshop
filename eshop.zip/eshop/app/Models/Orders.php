<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Orders extends Model
{
    use HasFactory;

    protected $table = 'tbl_tr_orders';
    protected $primaryKey = 'order_id';
    public $timestamps = false;

    protected $fillable = ['order_date','total_amount','cus_name','cus_mobile','cus_email','delivery_address'];
}
